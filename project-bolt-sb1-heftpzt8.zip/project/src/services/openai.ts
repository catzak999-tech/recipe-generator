import type { Recipe, RecipeIngredient, RecipeStep } from '../types/recipe';
import { DEFAULT_PANTRY, type PromptOptions } from '../utils/promptBuilder';
import { callServer } from './server';

function normalize(s: string) {
  return s.toLowerCase().trim()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ');
}

export const generateRecipe = async (
  promptParts: { system: string; user: string },
  opts: {
    ingredients: string[];
    pantryAllowed?: string[];
  }
): Promise<Recipe> => {
  try {
    const data = await callServer([
      { role: 'system', content: promptParts.system },
      { role: 'user', content: promptParts.user }
    ], { model: 'gpt-4', temperature: 0.7, max_tokens: 1400 });
    
    if (!data.choices?.[0]?.message?.content) {
      throw new Error('No recipe generated. Please try again.');
    }

    const content = data.choices[0].message.content.trim();
    
    try {
      const jsonStr = content.slice(content.indexOf('{'), content.lastIndexOf('}') + 1);
      let recipe = coerceRecipeShape(JSON.parse(jsonStr));
      
      // Add client-side ID
      recipe.id = Date.now().toString();
      
      // Validate ingredients
      const allowed = new Set([
        ...(opts.ingredients || []).map(normalize),
        ...((opts.pantryAllowed || DEFAULT_PANTRY).map(normalize))
      ]);
      
      const usViolations = (recipe.ingredientsUS || [])
        .map(i => normalize(i.item))
        .filter(it => !allowed.has(it));
      const metricViolations = (recipe.ingredientsMetric || [])
        .map(i => normalize(i.item))
        .filter(it => !allowed.has(it));
      const violations = Array.from(new Set([...usViolations, ...metricViolations]));

      if (violations.length) {
        // Try one corrective regeneration
        try {
          const corrective = await fetch(OPENAI_API_URL, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              model: 'gpt-4',
              temperature: 0.5,
              max_tokens: 1200,
              messages: [
                { 
                  role: 'system', 
                  content: promptParts.system + `\nYou violated the ingredient contract. Remove these items entirely: ${JSON.stringify(violations)}. Do not replace with other non-allowed items. If inputs cannot yield a main, switch dishType to 'spice-blend', 'marinade', 'dressing', or 'sauce'. JSON only.`
                },
                { role: 'user', content: promptParts.user }
              ]
            })
          });

          if (corrective.ok) {
            const fix = await corrective.json();
            const fixedContent = fix.choices?.[0]?.message?.content || '';
            const fixedJsonStr = fixedContent.slice(fixedContent.indexOf('{'), fixedContent.lastIndexOf('}') + 1);
            const fixed = coerceRecipeShape(JSON.parse(fixedJsonStr));
            fixed.id = Date.now().toString();

            // Final validation pass
            const usV2 = (fixed.ingredientsUS || [])
              .map(i => normalize(i.item))
              .filter(it => !allowed.has(it));
            const mV2 = (fixed.ingredientsMetric || [])
              .map(i => normalize(i.item))
              .filter(it => !allowed.has(it));
            
            if (usV2.length === 0 && mV2.length === 0) {
              return fixed;
            }
            
            fixed.violations = Array.from(new Set([...usV2, ...mV2]));
            return fixed;
          }
        } catch (correctionError) {
          console.error('Correction attempt failed:', correctionError);
        }
        
        recipe.violations = violations;
      }

      // ---- time validation ----
      const limitMins = Number.isFinite(+promptParts.user.match(/Time limit:\s*([0-9]+)/)?.[1])
        ? parseInt(promptParts.user.match(/Time limit:\s*([0-9]+)/)![1], 10)
        : Infinity;

      const declaredTotal = minutesFrom(recipe.totalTime);
      const stepsSum = sumStepMinutes(recipe.steps || []);
      const effectiveTotal = Math.max(declaredTotal, stepsSum);

      let timeViolation = effectiveTotal > limitMins;

      // Quick heuristic: detect forbidden waits for short limits
      const hasLongWait = (recipe.steps || []).some(s => {
        const st = (s.step || '').toLowerCase();
        const waitWords = /(marinate|rest|chill|proof|soak)/.test(st);
        const t = typeof s.time === 'string' ? minutesFrom(s.time) : 0;
        return waitWords && t > Math.max(0, limitMins - 2);
      });

      if (hasLongWait) timeViolation = true;

      if (timeViolation) {
        // corrective regen: forbid slow proteins and long waits
        const correctiveSys = promptParts.system + `
HARD TIME GUARD:
- Your previous plan exceeded the user's time limit (${limitMins} min) or included long resting.
- Choose a dishType that can be fully made and ready-to-eat within ${limitMins} minutes.
- If raw proteins cannot be cooked safely in time, omit them and explain why.
- No marination/resting longer than the available minutes. JSON only.`;

        try {
          const fix = await callServer([
            { role: 'system', content: correctiveSys },
            { role: 'user', content: promptParts.user }
          ], { model: 'gpt-4', temperature: 0.5, max_tokens: 1200 });
          
          const fixedContent = fix?.choices?.[0]?.message?.content ?? '';
          const fixedJsonStr = sliceToJson(fixedContent);
          const fixedRecipe = coerceRecipeShape(JSON.parse(fixedJsonStr));

          const fixedDeclared = minutesFrom(fixedRecipe.totalTime);
          const fixedStepsSum = sumStepMinutes(fixedRecipe.steps || []);
          const fixedEffective = Math.max(fixedDeclared, fixedStepsSum);

          if (fixedEffective <= limitMins) {
            recipe = fixedRecipe;
          } else {
            // attach violation note for UI
            recipe.notes = [...(recipe.notes || []), `Time violation: needs ${fixedEffective} min > limit ${limitMins} min`];
          }
        } catch (correctionError) {
          console.error('Correction attempt failed:', correctionError);
          recipe.notes = [...(recipe.notes || []), 'Time guard corrective request failed'];
        }
      }

      // Validate the recipe structure
      if (!recipe.title || !recipe.description || !Array.isArray(recipe.ingredientsUS) || 
          !Array.isArray(recipe.ingredientsMetric) || !Array.isArray(recipe.steps) || 
          !Array.isArray(recipe.tips)) {
        throw new Error('Invalid recipe format received');
      }

      return recipe;
    } catch (parseError) {
      console.error('Parse error:', parseError);
      console.error('Raw content:', content);
      throw new Error('Failed to parse recipe. Please try again.');
    }

  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Network error. Please check your connection and try again.');
  }
};

function sliceToJson(content: string): string {
  const firstBrace = content.indexOf('{');
  const lastBrace = content.lastIndexOf('}');
  
  if (firstBrace === -1 || lastBrace === -1) {
    throw new Error('No valid JSON found in response');
  }
  
  return content.slice(firstBrace, lastBrace + 1);
}

// ---- Shape coercion helpers ----
function toIngArray(x: any): RecipeIngredient[] {
  // Already array of objects
  if (Array.isArray(x)) {
    return x.map((it: any) => {
      if (typeof it === 'string') return { item: it, amount: '' };
      if (it && typeof it === 'object') {
        if ('item' in it && 'amount' in it) {
          return { 
            item: String(it.item), 
            amount: String(it.amount), 
            optional: !!it.optional 
          };
        }
        // Handle single-entry objects inside array
        const entries = Object.entries(it || {});
        if (entries.length === 1) {
          const [k, v] = entries[0] as [string, any];
          return { item: String(k), amount: String(v ?? '') };
        }
      }
      return null;
    }).filter(Boolean) as RecipeIngredient[];
  }
  
  // Dictionary -> array
  if (x && typeof x === 'object') {
    return Object.entries(x).map(([k, v]) => ({ 
      item: String(k), 
      amount: String(v as any) 
    }));
  }
  
  return [];
}

function toUsedArray(x: any): { item: string; reason?: string }[] {
  if (!x) return [];
  if (Array.isArray(x)) {
    return x.map((it: any) => typeof it === 'string'
      ? { item: it }
      : { 
          item: String(it.item ?? ''), 
          reason: it.reason ? String(it.reason) : undefined 
        }
    ).filter(r => r.item);
  }
  return [];
}

function toOmittedArray(x: any): { item: string; reason: string }[] {
  if (!x) return [];
  if (Array.isArray(x)) {
    return x.map((it: any) => {
      if (typeof it === 'string') return { item: it, reason: 'Provided but not used' };
      return { 
        item: String(it.item ?? ''), 
        reason: String(it.reason ?? 'Provided but not used') 
      };
    }).filter(r => r.item);
  }
  return [];
}

function toStepsArray(x: any): RecipeStep[] {
  if (!Array.isArray(x)) return [];
  return x.map((s: any) => {
    if (typeof s === 'string') return { step: s };
    if (s && typeof s === 'object') {
      // Accept "instruction" alias
      const stepText = s.step || s.instruction;
      if (!stepText) return null;
      return {
        step: String(stepText),
        time: s.time ? String(s.time) : undefined,
        temp: s.temp ? String(s.temp) : undefined,
        check: s.check ? String(s.check) : undefined,
        tip: s.tip ? String(s.tip) : undefined,
      };
    }
    return null;
  }).filter(Boolean) as RecipeStep[];
}

function normalizeDishType(dt: any) {
  if (!dt) return undefined;
  const s = String(dt).toLowerCase().trim();
  if (s.includes('spice')) return 'spice-blend';
  if (s.includes('marinade')) return 'marinade';
  if (s.includes('dress')) return 'dressing';
  if (s.includes('sauce')) return 'sauce';
  if (s.includes('side')) return 'side';
  if (s.includes('drink')) return 'drink';
  if (s.includes('dessert')) return 'dessert';
  return 'main';
}

function coerceRecipeShape(obj: any): Recipe {
  const r: any = { ...obj };

  r.id = r.id ? String(r.id) : String(Date.now());
  r.title = String(r.title ?? 'Recipe');
  r.description = String(r.description ?? '');
  r.servings = Number(r.servings ?? 2);
  r.prepTime = String(r.prepTime ?? '');
  r.cookTime = String(r.cookTime ?? '');
  r.totalTime = String(r.totalTime ?? '');
  r.cuisine = r.cuisine ? String(r.cuisine) : undefined;
  r.dishType = normalizeDishType(r.dishType);

  r.usedIngredients = toUsedArray(r.usedIngredients);
  r.omittedIngredients = toOmittedArray(r.omittedIngredients);
  r.pantryStaplesUsed = Array.isArray(r.pantryStaplesUsed) ? r.pantryStaplesUsed.map(String) : [];

  r.ingredientsUS = toIngArray(r.ingredientsUS);
  r.ingredientsMetric = toIngArray(r.ingredientsMetric);

  // If one list is empty, mirror the other so UI never crashes
  if ((!r.ingredientsUS || r.ingredientsUS.length === 0) && r.ingredientsMetric?.length) {
    r.ingredientsUS = r.ingredientsMetric;
  }
  if ((!r.ingredientsMetric || r.ingredientsMetric.length === 0) && r.ingredientsUS?.length) {
    r.ingredientsMetric = r.ingredientsUS;
  }

  r.steps = toStepsArray(r.steps);
  r.tips = Array.isArray(r.tips) ? r.tips.map(String) : [];
  r.substitutions = Array.isArray(r.substitutions)
    ? r.substitutions.map((s: any) => ({ 
        from: String(s.from ?? ''), 
        to: String(s.to ?? ''), 
        reason: String(s.reason ?? '') 
      }))
    : [];
  r.notes = Array.isArray(r.notes) ? r.notes.map(String) : undefined;

  r.score = r.score && typeof r.score === 'object'
    ? { 
        taste: Number(r.score.taste ?? 8), 
        simplicity: Number(r.score.simplicity ?? 8), 
        overall: Number(r.score.overall ?? 8) 
      }
    : { taste: 8, simplicity: 8, overall: 8 };

  r.violations = Array.isArray(r.violations) ? r.violations.map(String) : [];

  // Final polish fields
  r.storageLife = r.storageLife ? String(r.storageLife) : undefined;
  r.yield = r.yield ? String(r.yield) : undefined;
  r.usageExamples = Array.isArray(r.usageExamples) ? r.usageExamples.map(String) : undefined;

  return r as Recipe;
}
 function minutesFrom(s: string): number {
   if (!s) return 0;
   const txt = s.toLowerCase();
   const rangeMatch = txt.match(/(\d+)\s*(?:-|–|to)\s*(\d+)\s*min/);
   if (rangeMatch) return parseInt(rangeMatch[2], 10);
   const hrMin = txt.match(/(\d+)\s*(?:h|hr|hour)s?\s*(\d+)?\s*(?:min)?/);
   if (hrMin) {
     const h = parseInt(hrMin[1], 10);
     const m = hrMin[2] ? parseInt(hrMin[2], 10) : 0;
     return h * 60 + m;
   }
   const hrsOnly = txt.match(/(\d+)\s*(?:h|hr|hour)s?/);
   if (hrsOnly) return parseInt(hrsOnly[1], 10) * 60;
   const minsOnly = txt.match(/(\d+)\s*min/);
   if (minsOnly) return parseInt(minsOnly[1], 10);
   const num = txt.match(/^\s*(\d+)\s*$/); // bare numbers
   if (num) return parseInt(num[1], 10);
   return 0;
 }
 
 function sumStepMinutes(steps: any[]): number {
   if (!Array.isArray(steps)) return 0;
   let total = 0;
   for (const s of steps) {
     const t = typeof s?.time === 'string' ? minutesFrom(s.time) : 0;
     total += t;
   }
   return total;
 }