// src/services/server.ts
export async function callServer(messages: any[], opts?: { model?: string; temperature?: number; max_tokens?: number }) {
  const token = import.meta.env.VITE_PUBLIC_APP_TOKEN || '';
  const res = await fetch('/api/generate', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      ...(token ? { 'x-app-token': token } : {})
    },
    body: JSON.stringify({
      messages,
      model: opts?.model ?? 'gpt-4',
      temperature: opts?.temperature ?? 0.7,
      max_tokens: opts?.max_tokens ?? 1400
    })
  });
  if (!res.ok) {
    const detail = await res.text().catch(()=> '');
    throw new Error(`Server error ${res.status}: ${detail}`);
  }
  // Return parsed JSON object from OpenAI
  return res.json();
}