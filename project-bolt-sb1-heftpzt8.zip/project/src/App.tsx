import React, { useState, useEffect } from 'react';
import { SmartRecipeGenerator } from './components/SmartRecipeGenerator';
import { ThemeToggle } from './components/ThemeToggle';

type Theme = 'light' | 'dark';

function App({ initialTheme = 'light' }: { initialTheme?: Theme }) {
  const [theme, setTheme] = useState<Theme>(initialTheme);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 dark:bg-gray-900 dark:text-gray-100 transition-colors duration-200">
      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="flex justify-end mb-8 px-4">
          <ThemeToggle theme={theme} onToggle={toggleTheme} />
        </div>

        {/* Main Content */}
        <div className="flex items-start justify-center">
          <SmartRecipeGenerator />
        </div>
      </div>
    </div>
  );
}

export default App;