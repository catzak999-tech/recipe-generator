import { useState, useEffect, useRef } from 'react';

export interface Timer {
  id: string;
  duration: number; // in seconds
  remaining: number;
  isActive: boolean;
  isComplete: boolean;
}

export const useTimer = () => {
  const [timers, setTimers] = useState<Timer[]>([]);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (timers.some(t => t.isActive)) {
      intervalRef.current = setInterval(() => {
        setTimers(prev => prev.map(timer => {
          if (!timer.isActive || timer.remaining <= 0) return timer;
          
          const newRemaining = timer.remaining - 1;
          if (newRemaining <= 0) {
            // Timer completed
            playBeep();
            return { ...timer, remaining: 0, isActive: false, isComplete: true };
          }
          
          return { ...timer, remaining: newRemaining };
        }));
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timers]);

  const startTimer = (id: string, durationMinutes: number) => {
    const duration = durationMinutes * 60;
    setTimers(prev => {
      const existing = prev.find(t => t.id === id);
      if (existing) {
        return prev.map(t => 
          t.id === id 
            ? { ...t, remaining: duration, isActive: true, isComplete: false }
            : t
        );
      } else {
        return [...prev, {
          id,
          duration,
          remaining: duration,
          isActive: true,
          isComplete: false,
        }];
      }
    });
  };

  const stopTimer = (id: string) => {
    setTimers(prev => prev.map(t => 
      t.id === id ? { ...t, isActive: false } : t
    ));
  };

  const resetTimer = (id: string) => {
    setTimers(prev => prev.map(t => 
      t.id === id 
        ? { ...t, remaining: t.duration, isActive: false, isComplete: false }
        : t
    ));
  };

  const getTimer = (id: string): Timer | undefined => {
    return timers.find(t => t.id === id);
  };

  return { startTimer, stopTimer, resetTimer, getTimer };
};

const playBeep = () => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
  } catch (error) {
    // Fallback for browsers that don't support Web Audio API
    console.log('Timer completed!');
  }
};

export const formatTime = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};