export const DEFAULT_PANTRY = [
  'water', 'salt', 'pepper', 'olive oil', 'vegetable oil', 'butter', 'sugar', 'honey', 'vinegar', 'lemon juice'
];

function normalize(s: string) {
  return s.toLowerCase().trim()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ');
}

export interface PromptOptions {
  ingredients: string[];
  excludes: string[];
  cuisine: string;
  timeLimit: string;
  skill: 'Beginner' | 'Normal' | 'Advanced';
  smartSelect: boolean;
  strictMode: boolean;
  pantryAllowed: string[];
  unitMode: 'us' | 'metric';
}

export function buildRecipePrompt(opts: PromptOptions) {
  const allowed = Array.from(new Set([
    ...opts.ingredients.map(normalize),
    ...opts.pantryAllowed.map(normalize)
  ]));

  const excludes = Array.from(new Set(opts.excludes.map(normalize)));

  const cuisineRule = opts.cuisine && opts.cuisine !== 'Auto'
    ? `Enforce ${opts.cuisine} flavor profile. If user provided items that clash with this cuisine, list them under "omittedIngredients" with reasons and do not use them.`
    : `Cuisine may be chosen to best fit the ingredients. Do not import foreign flavor bases unless they are explicitly listed by the user.`;

  const strictRule = opts.strictMode
    ? `STRICT INGREDIENT CONTRACT: You are FORBIDDEN from using any ingredient that is not present in ALLOWED_INGREDIENTS. If a recipe type needs something essential that is not allowed, adapt the dish type to fit the inputs. For example, if only spices are provided, return a "spice-blend" or "dry rub" with ratios and usage instructions.`
    : `Do not add extra ingredients unless absolutely essential. If you add any minor essential (like water, salt, oil), include them under "pantryStaplesUsed". Otherwise prefer using only user-provided items.`;

  const smartSelectRule = opts.smartSelect
    ? `SMART SELECT ON: Choose the best subset of user ingredients for flavor and coherence. Explain every omission in "omittedIngredients".`
    : `SMART SELECT OFF: Try to use most user ingredients reasonably. Still omit anything that ruins flavor and explain why.`;

  const timeSkill = `
Respect time limit "${opts.timeLimit}". Use concurrency when possible. 
Skill level "${opts.skill}" controls step detail. 
Beginner = more safety and visual checks. Advanced = tighter steps, still precise.`;

  // HARD schema example using arrays of objects only
  const schemaExample = `
Return ONLY JSON. Do not include markdown fences or commentary.
Use EXACTLY these array-of-object shapes (no dictionaries):

{
  "id": "string",
  "title": "string",
  "description": "string",
  "servings": 4,
  "prepTime": "15 min",
  "cookTime": "25 min",
  "totalTime": "40 min",
  "cuisine": "Mediterranean",
  "dishType": "main",
  "usedIngredients": [{ "item": "lemon", "reason": "adds brightness" }],
  "omittedIngredients": [{ "item": "lime", "reason": "clashes with chosen profile" }],
  "pantryStaplesUsed": ["olive oil","salt","pepper"],
  "ingredientsUS": [{ "item": "paprika", "amount": "2 tbsp" }],
  "ingredientsMetric": [{ "item": "paprika", "amount": "30 g" }],
  "steps": [{ "step": "Combine spices.", "time": "2 min", "check": "evenly mixed" }],
  "tips": ["simple serving tip"],
  "substitutions": [{ "from": "anchovy paste", "to": "capers", "reason": "similar umami" }],
  "notes": ["optional note"],
  "score": { "taste": 9, "simplicity": 8, "overall": 8.5 },
  "violations": []
}
`;

  const system = `
You are a professional recipe developer. You return JSON only that matches the Recipe interface. 
Never include commentary or markdown outside JSON.
${cuisineRule}
${smartSelectRule}
${strictRule}
ALLOWED_INGREDIENTS = ${JSON.stringify(allowed)}
`.trim();

  const user = [
    `User ingredients: ${opts.ingredients.join(', ')}`,
    `Excluded: ${opts.excludes.length ? opts.excludes.join(', ') : '(none)'}`,
    `Cuisine: ${opts.cuisine}`,
    `Time limit: ${opts.timeLimit}`,
    `Skill: ${opts.skill}`,
    `Unit mode requested: ${opts.unitMode}`,
    `Return ONLY JSON. Arrays of objects only. No dictionaries. No "instruction" fields.`
  ].join('\n');

  return { system, user };
}

export const cleanJsonResponse = (response: string): string => {
  // Find the first { and last } to extract just the JSON
  const firstBrace = response.indexOf('{');
  const lastBrace = response.lastIndexOf('}');
  
  if (firstBrace === -1 || lastBrace === -1) {
    throw new Error('No valid JSON found in response');
  }
  
  return response.slice(firstBrace, lastBrace + 1);
};