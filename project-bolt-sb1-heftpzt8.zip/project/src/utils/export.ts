import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import type { Recipe, UnitMode } from '../types/recipe';

export const copyToClipboard = async (text: string): Promise<void> => {
  try {
    await navigator.clipboard.writeText(text);
  } catch (error) {
    // Fallback for older browsers
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);
  }
};

export const copyIngredients = (recipe: Recipe, unitMode: UnitMode): string => {
  const ingredients = unitMode === 'us' ? recipe.ingredientsUS : recipe.ingredientsMetric;
  return ingredients
    .map(ing => `${ing.amount} ${ing.item}${ing.optional ? ' (optional)' : ''}`)
    .join('\n');
};

export const copySteps = (recipe: Recipe): string => {
  return recipe.steps
    .map((step, i) => `${i + 1}. ${step.step}${step.time ? ` (${step.time})` : ''}${step.temp ? ` at ${step.temp}` : ''}`)
    .join('\n');
};

export const copyAll = (recipe: Recipe, unitMode: UnitMode): string => {
  const sections = [
    `# ${recipe.title}`,
    `${recipe.description}`,
    ``,
    `**Servings:** ${recipe.servings} | **Prep:** ${recipe.prepTime} | **Cook:** ${recipe.cookTime} | **Total:** ${recipe.totalTime}`,
    recipe.cuisine ? `**Cuisine:** ${recipe.cuisine}` : '',
    ``,
    `## Ingredients`,
    copyIngredients(recipe, unitMode),
    ``,
    `## Instructions`,
    copySteps(recipe),
    ``,
    `## Tips`,
    ...recipe.tips.map(tip => `- ${tip}`),
  ].filter(Boolean).join('\n');
  
  return sections;
};

export const exportToPDF = async (elementId: string, filename: string): Promise<void> => {
  const element = document.getElementById(elementId);
  if (!element) throw new Error('Element not found');

  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    allowTaint: true,
  });

  const imgData = canvas.toDataURL('image/png');
  const pdf = new jsPDF('p', 'mm', 'a4');
  
  const imgWidth = 210; // A4 width in mm
  const pageHeight = 295; // A4 height in mm
  const imgHeight = (canvas.height * imgWidth) / canvas.width;
  
  let heightLeft = imgHeight;
  let position = 0;

  pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
  heightLeft -= pageHeight;

  while (heightLeft >= 0) {
    position = heightLeft - imgHeight;
    pdf.addPage();
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
  }

  pdf.save(filename);
};

export const exportToJSON = (recipe: Recipe): void => {
  const dataStr = JSON.stringify(recipe, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `${recipe.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
};