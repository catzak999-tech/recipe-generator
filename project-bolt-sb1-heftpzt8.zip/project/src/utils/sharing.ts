import type { GenerationSettings } from '../types/recipe';

export const buildShareUrl = (settings: GenerationSettings): string => {
  const params = new URLSearchParams();
  
  if (settings.ingredientsInput) params.set('ingredients', settings.ingredientsInput);
  if (settings.excludedInput) params.set('excluded', settings.excludedInput);
  if (settings.cuisine !== 'Auto') params.set('cuisine', settings.cuisine);
  if (settings.timeLimit !== 'Auto') params.set('time', settings.timeLimit);
  if (settings.skillLevel !== 'Normal') params.set('skill', settings.skillLevel);
  if (!settings.smartSelect) params.set('smart', 'false');
  
  return `${window.location.origin}${window.location.pathname}?${params.toString()}`;
};

export const parseShareUrl = (): Partial<GenerationSettings> => {
  const params = new URLSearchParams(window.location.search);
  
  return {
    ingredientsInput: params.get('ingredients') || '',
    excludedInput: params.get('excluded') || '',
    cuisine: params.get('cuisine') || 'Auto',
    timeLimit: params.get('time') || 'Auto',
    skillLevel: params.get('skill') || 'Normal',
    smartSelect: params.get('smart') !== 'false',
  };
};