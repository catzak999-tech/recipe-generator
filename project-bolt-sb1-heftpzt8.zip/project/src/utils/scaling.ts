export const scaleAmount = (amount: string, factor: number): string => {
  if (factor === 1) return amount;
  
  // Match patterns like "1", "1.5", "1/2", "3/4", "1 1/2", "2 3/4"
  const fractionRegex = /^(\d+)?\s*(\d+)\/(\d+)/;
  const decimalRegex = /^(\d+(?:\.\d+)?)/;
  
  let numericValue = 0;
  let restOfString = amount;
  
  // Try to match mixed fraction first (e.g., "1 1/2")
  const mixedMatch = amount.match(/^(\d+)\s+(\d+)\/(\d+)(.*)$/);
  if (mixedMatch) {
    const whole = parseInt(mixedMatch[1]);
    const numerator = parseInt(mixedMatch[2]);
    const denominator = parseInt(mixedMatch[3]);
    numericValue = whole + (numerator / denominator);
    restOfString = mixedMatch[4];
  } else {
    // Try simple fraction (e.g., "3/4")
    const fractionMatch = amount.match(fractionRegex);
    if (fractionMatch) {
      const whole = fractionMatch[1] ? parseInt(fractionMatch[1]) : 0;
      const numerator = parseInt(fractionMatch[2]);
      const denominator = parseInt(fractionMatch[3]);
      numericValue = whole + (numerator / denominator);
      restOfString = amount.substring(fractionMatch[0].length);
    } else {
      // Try decimal/integer (e.g., "1.5", "2")
      const decimalMatch = amount.match(decimalRegex);
      if (decimalMatch) {
        numericValue = parseFloat(decimalMatch[1]);
        restOfString = amount.substring(decimalMatch[0].length);
      } else {
        // No number found, return original
        return amount;
      }
    }
  }
  
  // Scale the numeric value
  const scaledValue = numericValue * factor;
  
  // Format the result
  let formattedValue: string;
  
  // Check if it's close to a common fraction
  const commonFractions = [
    { decimal: 0.125, fraction: '1/8' },
    { decimal: 0.25, fraction: '1/4' },
    { decimal: 0.333, fraction: '1/3' },
    { decimal: 0.5, fraction: '1/2' },
    { decimal: 0.667, fraction: '2/3' },
    { decimal: 0.75, fraction: '3/4' },
  ];
  
  const tolerance = 0.05;
  const fractionalPart = scaledValue % 1;
  const wholePart = Math.floor(scaledValue);
  
  const matchingFraction = commonFractions.find(
    f => Math.abs(fractionalPart - f.decimal) < tolerance
  );
  
  if (matchingFraction && fractionalPart > 0.1) {
    if (wholePart > 0) {
      formattedValue = `${wholePart} ${matchingFraction.fraction}`;
    } else {
      formattedValue = matchingFraction.fraction;
    }
  } else {
    // Use decimal, but clean up trailing zeros
    const rounded = Math.round(scaledValue * 100) / 100;
    formattedValue = rounded % 1 === 0 ? rounded.toString() : rounded.toFixed(2).replace(/\.?0+$/, '');
  }
  
  return formattedValue + restOfString;
};