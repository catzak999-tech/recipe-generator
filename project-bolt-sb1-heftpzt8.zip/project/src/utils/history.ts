import type { Recipe, GenerationSettings, HistoryItem } from '../types/recipe';

const HISTORY_KEY = 'recipe_history';
const MAX_HISTORY_ITEMS = 10;

export const saveToHistory = (recipe: Recipe, settings: GenerationSettings): void => {
  const history = getHistory();
  
  const historyItem: HistoryItem = {
    id: recipe.id,
    recipe,
    settings,
    timestamp: Date.now(),
  };
  
  // Remove existing item with same ID if it exists
  const filteredHistory = history.filter(item => item.id !== recipe.id);
  
  // Add new item to the beginning
  const newHistory = [historyItem, ...filteredHistory].slice(0, MAX_HISTORY_ITEMS);
  
  localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
};

export const getHistory = (): HistoryItem[] => {
  try {
    const stored = localStorage.getItem(HISTORY_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading history:', error);
    return [];
  }
};

export const deleteFromHistory = (id: string): void => {
  const history = getHistory();
  const filtered = history.filter(item => item.id !== id);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(filtered));
};

export const formatTimestamp = (timestamp: number): string => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } else if (diffDays === 1) {
    return 'Yesterday';
  } else if (diffDays < 7) {
    return `${diffDays} days ago`;
  } else {
    return date.toLocaleDateString();
  }
};