import React, { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import QRCode from 'qrcode';

interface QRModalProps {
  url: string;
  onClose: () => void;
}

export const QRModal: React.FC<QRModalProps> = ({ url, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, url, {
        width: 256,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      });
    }
  }, [url]);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-sm w-full">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
            Scan to Open on Phone
          </h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-500 dark:text-gray-400" />
          </button>
        </div>
        
        <div className="flex justify-center mb-4">
          <canvas ref={canvasRef} className="border border-gray-200 dark:border-gray-700 rounded-lg" />
        </div>
        
        <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
          Scan this QR code with your phone's camera to open the recipe
        </p>
      </div>
    </div>
  );
};