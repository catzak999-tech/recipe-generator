import React from 'react';
import { Clock, Trash2, ChefHat } from 'lucide-react';
import { getHistory, deleteFromHistory, formatTimestamp } from '../utils/history';
import type { HistoryItem, GenerationSettings } from '../types/recipe';

interface HistoryPanelProps {
  onLoadRecipe: (item: HistoryItem) => void;
  onHistoryChange: () => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({ onLoadRecipe, onHistoryChange }) => {
  const history = getHistory();

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteFromHistory(id);
    onHistoryChange();
  };

  if (history.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-8 text-center">
        <ChefHat className="h-12 w-12 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
          No Recipe History
        </h3>
        <p className="text-gray-600 dark:text-gray-400">
          Your generated recipes will appear here for easy access
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6">
      <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center gap-2">
        <Clock className="h-5 w-5" />
        Recent Recipes
      </h3>
      
      <div className="space-y-3">
        {history.map((item) => (
          <div
            key={item.id}
            onClick={() => onLoadRecipe(item)}
            className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 
                     hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg cursor-pointer 
                     transition-colors group"
          >
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-gray-900 dark:text-gray-100 truncate">
                {item.recipe.title}
              </h4>
              <div className="flex items-center gap-4 mt-1 text-sm text-gray-500 dark:text-gray-400">
                <span>{formatTimestamp(item.timestamp)}</span>
                <span>{item.recipe.cuisine}</span>
                <span>{item.recipe.servings} servings</span>
              </div>
            </div>
            
            <button
              onClick={(e) => handleDelete(item.id, e)}
              className="p-2 text-gray-400 hover:text-red-500 dark:hover:text-red-400 
                       opacity-0 group-hover:opacity-100 transition-all rounded-lg
                       hover:bg-red-50 dark:hover:bg-red-900/20"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};