import React from 'react';
import { Loader2, ChefHat } from 'lucide-react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <ChefHat className="h-12 w-12 text-gray-500 dark:text-gray-400" />
          <Loader2 className="h-6 w-6 animate-spin text-blue-500 absolute -top-1 -right-1" />
        </div>
        <div className="text-center">
          <p className="text-lg font-medium text-gray-900 dark:text-gray-100 animate-pulse">
            Crafting your perfect recipe...
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Selecting the best ingredients and techniques
          </p>
        </div>
      </div>
    </div>
  );
};