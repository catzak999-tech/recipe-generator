import React from 'react';
import { Timer, Play, Pause, RotateCcw } from 'lucide-react';
import { useTimer, formatTime } from '../hooks/useTimer';

interface TimerButtonProps {
  stepId: string;
  timeString: string; // e.g., "10 min"
}

export const TimerButton: React.FC<TimerButtonProps> = ({ stepId, timeString }) => {
  const { startTimer, stopTimer, resetTimer, getTimer } = useTimer();
  
  // Parse time string to get minutes
  const parseTime = (timeStr: string): number => {
    const match = timeStr.match(/(\d+)\s*min/i);
    return match ? parseInt(match[1]) : 0;
  };

  const minutes = parseTime(timeString);
  const timer = getTimer(stepId);

  if (minutes === 0) return null;

  const handleStart = () => startTimer(stepId, minutes);
  const handleStop = () => stopTimer(stepId);
  const handleReset = () => resetTimer(stepId);

  return (
    <div className="flex items-center gap-2">
      {!timer || (!timer.isActive && !timer.isComplete) ? (
        <button
          onClick={handleStart}
          className="flex items-center gap-1 px-3 py-1 bg-blue-100 dark:bg-blue-900/30 
                   text-blue-700 dark:text-blue-300 rounded-full text-sm font-medium
                   hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-colors"
        >
          <Play className="h-3 w-3" />
          Start {timeString} Timer
        </button>
      ) : (
        <div className="flex items-center gap-2">
          <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${
            timer.isComplete 
              ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 animate-pulse'
              : 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300'
          }`}>
            <Timer className="h-3 w-3" />
            {timer.isComplete ? 'Done!' : formatTime(timer.remaining)}
          </div>
          
          {timer.isActive && (
            <button
              onClick={handleStop}
              className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 
                       dark:hover:text-gray-200 transition-colors"
            >
              <Pause className="h-3 w-3" />
            </button>
          )}
          
          <button
            onClick={handleReset}
            className="p-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 
                     dark:hover:text-gray-200 transition-colors"
          >
            <RotateCcw className="h-3 w-3" />
          </button>
        </div>
      )}
    </div>
  );
};