import React from 'react';
import type { UnitMode } from '../types/recipe';

interface UnitToggleProps {
  unitMode: UnitMode;
  onUnitModeChange: (mode: UnitMode) => void;
}

export const UnitToggle: React.FC<UnitToggleProps> = ({ unitMode, onUnitModeChange }) => {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Units:</span>
      <div className="flex bg-gray-200 dark:bg-gray-700 rounded-lg p-1">
        <button
          onClick={() => onUnitModeChange('us')}
          className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
            unitMode === 'us'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
          }`}
        >
          US
        </button>
        <button
          onClick={() => onUnitModeChange('metric')}
          className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
            unitMode === 'metric'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
          }`}
        >
          Metric
        </button>
      </div>
    </div>
  );
};