import React from 'react';
import { Minus, Plus } from 'lucide-react';

interface ServingsControlProps {
  servings: number;
  onServingsChange: (servings: number) => void;
}

export const ServingsControl: React.FC<ServingsControlProps> = ({ servings, onServingsChange }) => {
  const handleDecrease = () => {
    if (servings > 1) {
      onServingsChange(servings - 1);
    }
  };

  const handleIncrease = () => {
    if (servings < 20) {
      onServingsChange(servings + 1);
    }
  };

  return (
    <div className="flex items-center gap-3">
      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Servings:</span>
      <div className="flex items-center gap-2">
        <button
          onClick={handleDecrease}
          disabled={servings <= 1}
          className="p-1 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300
                   hover:bg-gray-300 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed
                   transition-colors"
        >
          <Minus className="h-4 w-4" />
        </button>
        
        <span className="w-8 text-center font-medium text-gray-900 dark:text-gray-100">
          {servings}
        </span>
        
        <button
          onClick={handleIncrease}
          disabled={servings >= 20}
          className="p-1 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300
                   hover:bg-gray-300 dark:hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed
                   transition-colors"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};