import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { DEFAULT_PANTRY } from '../utils/promptBuilder';
import type { GenerationSettings } from '../types/recipe';

interface GenerationControlsProps {
  settings: GenerationSettings;
  onSettingsChange: (settings: Partial<GenerationSettings>) => void;
}

export const GenerationControls: React.FC<GenerationControlsProps> = ({
  settings,
  onSettingsChange
}) => {
  const handlePantryToggle = (item: string) => {
    const current = settings.pantryAllowed || DEFAULT_PANTRY;
    const updated = current.includes(item)
      ? current.filter(i => i !== item)
      : [...current, item];
    onSettingsChange({ pantryAllowed: updated });
  };

  const pantryItems = [
    'water', 'salt', 'pepper', 'olive oil', 'vegetable oil', 'butter', 
    'sugar', 'honey', 'vinegar', 'lemon juice', 'garlic powder', 'onion powder'
  ];

  return (
    <div className="space-y-6">
      {/* Ingredients Input */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Your Ingredients
        </label>
        <textarea
          value={settings.ingredientsInput}
          onChange={(e) => onSettingsChange({ ingredientsInput: e.target.value })}
          placeholder="chicken breast, spinach, garlic, rice, onion, olive oil..."
          className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 
                   bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg
                   focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none
                   transition-all duration-200 resize-none"
          rows={3}
        />
      </div>

      {/* Smart Select Toggle */}
      <div className="flex items-center justify-between">
        <div>
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Smart Select Ingredients
          </label>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Choose best subset for flavor harmony
          </p>
        </div>
        <button
          onClick={() => onSettingsChange({ smartSelect: !settings.smartSelect })}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 ${
            settings.smartSelect ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'
          }`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
              settings.smartSelect ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
        </button>
      </div>

      {/* Strict Mode Toggle */}
      <div className="flex items-center justify-between">
        <div>
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Strict Mode
          </label>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Forbid any ingredients not provided by you
          </p>
        </div>
        <button
          onClick={() => onSettingsChange({ strictMode: !settings.strictMode })}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 ${
            settings.strictMode ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'
          }`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
              settings.strictMode ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
        </button>
      </div>

      {/* Strict Mode Warning */}
      {!settings.strictMode && (
        <div className="flex items-start gap-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
          <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-yellow-800 dark:text-yellow-200">
            Flexible mode may add small essentials. Turn Strict Mode ON to forbid any additions.
          </p>
        </div>
      )}

      {/* Exclude Ingredients */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Exclude Ingredients (Optional)
        </label>
        <input
          type="text"
          value={settings.excludedInput}
          onChange={(e) => onSettingsChange({ excludedInput: e.target.value })}
          placeholder="mushrooms, nuts, dairy..."
          className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 
                   bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg
                   focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none
                   transition-all duration-200"
        />
      </div>

      {/* Pantry Staples */}
      <div className="space-y-3">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Allowed Pantry Staples
        </label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {pantryItems.map((item) => {
            const isSelected = (settings.pantryAllowed || DEFAULT_PANTRY).includes(item);
            return (
              <button
                key={item}
                onClick={() => handlePantryToggle(item)}
                className={`px-3 py-2 text-sm rounded-lg border transition-colors duration-200 ${
                  isSelected
                    ? 'bg-blue-100 dark:bg-blue-900/30 border-blue-300 dark:border-blue-700 text-blue-800 dark:text-blue-200'
                    : 'bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600'
                }`}
              >
                {item}
              </button>
            );
          })}
        </div>
      </div>

      {/* Options Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Cuisine */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Cuisine
          </label>
          <select
            value={settings.cuisine}
            onChange={(e) => onSettingsChange({ cuisine: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 
                     bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg
                     focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none
                     transition-all duration-200"
          >
            <option value="Auto">Auto</option>
            <option value="American">American</option>
            <option value="Italian">Italian</option>
            <option value="Mexican">Mexican</option>
            <option value="Indian">Indian</option>
            <option value="Mediterranean">Mediterranean</option>
            <option value="Asian">Asian</option>
            <option value="Middle Eastern">Middle Eastern</option>
            <option value="French">French</option>
          </select>
        </div>

        {/* Time Limit */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Time Limit
          </label>
          <select
            value={settings.timeLimit}
            onChange={(e) => onSettingsChange({ timeLimit: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 
                     bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg
                     focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none
                     transition-all duration-200"
          >
            <option value="Auto">Auto</option>
            <option value="15">15 minutes</option>
            <option value="30">30 minutes</option>
            <option value="45">45 minutes</option>
            <option value="60">60 minutes</option>
          </select>
        </div>

        {/* Skill Level */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Skill Level
          </label>
          <select
            value={settings.skillLevel}
            onChange={(e) => onSettingsChange({ skillLevel: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 
                     bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg
                     focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none
                     transition-all duration-200"
          >
            <option value="Beginner">Beginner</option>
            <option value="Normal">Normal</option>
            <option value="Advanced">Advanced</option>
          </select>
        </div>
      </div>
    </div>
  );
};