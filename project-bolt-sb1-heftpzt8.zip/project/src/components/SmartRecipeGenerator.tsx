import React, { useState, useEffect } from 'react';
import { Sparkles, Shield } from 'lucide-react';
import { generateRecipe } from '../services/openai';
import { buildRecipePrompt, DEFAULT_PANTRY } from '../utils/promptBuilder';
import type { Recipe, GenerationSettings, HistoryItem } from '../types/recipe';
import { GenerationControls } from './GenerationControls';
import { RecipeDisplay } from './RecipeDisplay';
import { HistoryPanel } from './HistoryPanel';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorMessage } from './ErrorMessage';
import { ToastContainer } from './Toast';
import { saveToHistory } from '../utils/history';
import { parseShareUrl } from '../utils/sharing';
import { useToast } from '../hooks/useToast';

export const SmartRecipeGenerator: React.FC = () => {
  const [settings, setSettings] = useState<GenerationSettings>({
    ingredientsInput: '',
    smartSelect: true,
    strictMode: true,
    pantryAllowed: DEFAULT_PANTRY,
    excludedInput: '',
    cuisine: 'Auto',
    timeLimit: 'Auto',
    skillLevel: 'Normal'
  });
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [historyKey, setHistoryKey] = useState(0);

  const { toasts, showToast, removeToast } = useToast();

  // Load shared recipe on mount
  useEffect(() => {
    const sharedSettings = parseShareUrl();
    if (Object.keys(sharedSettings).length > 0) {
      setSettings(prev => ({ ...prev, ...sharedSettings }));
    }
  }, []);

  const handleSettingsChange = (newSettings: Partial<GenerationSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const handleGenerate = async () => {
    if (!settings.ingredientsInput.trim()) {
      setError('Please enter some ingredients');
      return;
    }

    setLoading(true);
    setError(null);
    setRecipe(null);

    try {
      const ingredients = settings.ingredientsInput.split(',').map(i => i.trim()).filter(Boolean);
      const excludes = settings.excludedInput.split(',').map(i => i.trim()).filter(Boolean);
      
      const promptParts = buildRecipePrompt({
        ingredients,
        excludes,
        cuisine: settings.cuisine,
        timeLimit: settings.timeLimit,
        skill: settings.skillLevel as 'Beginner' | 'Normal' | 'Advanced',
        smartSelect: settings.smartSelect,
        strictMode: settings.strictMode,
        pantryAllowed: settings.pantryAllowed,
        unitMode: 'us'
      });
      
      const generatedRecipe = await generateRecipe(promptParts, {
        ingredients,
        pantryAllowed: settings.pantryAllowed
      });
      setRecipe(generatedRecipe);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Generation error. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleLoadFromHistory = (item: HistoryItem) => {
    setRecipe(item.recipe);
    setSettings(item.settings);
  };

  const handleSaveToHistory = () => {
    if (recipe) {
      saveToHistory(recipe, settings);
      setHistoryKey(prev => prev + 1); // Force history refresh
    }
  };

  const canGenerate = settings.ingredientsInput.trim() && !loading;

  return (
    <div className="w-full max-w-2xl mx-auto px-4 space-y-8">
      {/* Input Section */}
      <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-8 shadow-lg">
        <div className="space-y-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
              Smart Recipe Generator
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              AI-powered recipe creation that chooses the best ingredients for perfect dishes
            </p>
            <div className="flex items-center justify-center gap-2 mt-3 text-sm text-green-600 dark:text-green-400">
              <Shield className="h-4 w-4" />
              <span>Requests are protected by a server key</span>
            </div>
          </div>

          <GenerationControls 
            settings={settings} 
            onSettingsChange={handleSettingsChange} 
          />

          <button
            onClick={handleGenerate}
            disabled={!canGenerate}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 
                     bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700
                     disabled:from-gray-400 disabled:to-gray-500 disabled:cursor-not-allowed
                     text-white font-medium rounded-lg shadow-lg hover:shadow-xl
                     transform transition-all duration-200 hover:-translate-y-0.5
                     disabled:transform-none disabled:hover:shadow-lg"
          >
            <Sparkles className="h-5 w-5" />
            {loading ? 'Generating Smart Recipe...' : 'Generate Smart Recipe'}
          </button>
        </div>
      </div>

      {/* Error Display */}
      {error && <ErrorMessage message={error} />}

      {/* Loading Display */}
      {loading && <LoadingSpinner />}

      {/* Recipe Display */}
      {recipe && !loading && (
        <RecipeDisplay 
          recipe={recipe} 
          settings={settings}
          onRegenerate={handleGenerate}
          onSaveToHistory={handleSaveToHistory}
          onShowToast={showToast}
        />
      )}

      {/* History Panel - only show when no current recipe */}
      {!recipe && !loading && (
        <HistoryPanel 
          key={historyKey}
          onLoadRecipe={handleLoadFromHistory}
          onHistoryChange={() => setHistoryKey(prev => prev + 1)}
        />
      )}

      {/* Toast Container */}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  );
};