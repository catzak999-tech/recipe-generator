import React from 'react';
import { Copy, Check } from 'lucide-react';
import { useClipboard } from '../hooks/useClipboard';

interface CopyButtonProps {
  text: string;
  id: string;
  size?: 'sm' | 'md';
}

export const CopyButton: React.FC<CopyButtonProps> = ({ text, id, size = 'sm' }) => {
  const { copied, copyToClipboard } = useClipboard();

  const sizeClasses = size === 'sm' ? 'p-1.5' : 'p-2';
  const iconSize = size === 'sm' ? 'h-4 w-4' : 'h-5 w-5';

  return (
    <button
      onClick={() => copyToClipboard(text, id)}
      className={`${sizeClasses} text-gray-500 dark:text-gray-400 
               hover:text-gray-700 dark:hover:text-gray-200
               hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-all duration-200`}
      title="Copy to clipboard"
    >
      {copied === id ? (
        <Check className={`${iconSize} text-green-500`} />
      ) : (
        <Copy className={iconSize} />
      )}
    </button>
  );
};