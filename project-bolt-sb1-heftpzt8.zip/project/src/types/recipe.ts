export type UnitMode = 'us' | 'metric';

export interface RecipeIngredient {
  item: string;
  amount: string;     // e.g., "1.5 lb" or "200 g"
  optional?: boolean;
}

export interface RecipeStep {
  step: string;
  time?: string;      // "10 min"
  temp?: string;      // "400°F" or "200°C"
  check?: string;     // "internal 165°F", "syrupy glaze", etc.
  tip?: string;
}

export interface RecipeScore {
  taste: number;       // 1-10
  simplicity: number;  // 1-10
  overall: number;     // 1-10
}

export interface Recipe {
  id: string;                 // generated client-side
  title: string;
  description: string;
  servings: number;
  prepTime: string;
  cookTime: string;
  totalTime: string;
  cuisine?: string;
  usedIngredients: { item: string; reason?: string }[];
  omittedIngredients: { item: string; reason: string }[];
  pantryStaplesUsed: string[];
  ingredientsUS: RecipeIngredient[];     // required
  ingredientsMetric: RecipeIngredient[];  // required
  steps: RecipeStep[];
  tips: string[];
  substitutions: { from: string; to: string; reason: string }[];
  notes?: string[];
  score: RecipeScore;

  // NEW optional, for enforcement + display
  dishType?: 'main' | 'side' | 'sauce' | 'spice-blend' | 'marinade' | 'dressing' | 'drink' | 'dessert';
  violations?: string[];  // any ingredient the model used that was not allowed

  // Final polish additions
  storageLife?: string;    // e.g., "up to 3 months airtight"
  yield?: string;          // e.g., "about 1/2 cup"
  usageExamples?: string[]; // 3 short bullet uses
}

export interface GenerationSettings {
  ingredientsInput: string;
  smartSelect: boolean;
  strictMode: boolean;
  pantryAllowed: string[];
  excludedInput: string;
  cuisine: string;
  timeLimit: string;
  skillLevel: string;
}

export interface HistoryItem {
  id: string;
  recipe: Recipe;
  timestamp: number;
  settings: GenerationSettings;
}

export interface ApiError {
  message: string;
  type: 'api' | 'parse' | 'network';
}